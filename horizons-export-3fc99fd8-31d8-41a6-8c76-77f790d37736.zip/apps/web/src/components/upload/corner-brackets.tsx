import { cn } from '@/lib/utils';

/** Bracket-like corner marks framing featured / interactive content. */
export function CornerBrackets({ className }: { className?: string }) {
	const base = 'pointer-events-none absolute h-4 w-4 border-accent';
	return (
		<span aria-hidden="true" className={cn('absolute inset-0', className)}>
			<span className={cn(base, 'left-0 top-0 border-l-2 border-t-2')} />
			<span className={cn(base, 'right-0 top-0 border-r-2 border-t-2')} />
			<span className={cn(base, 'bottom-0 left-0 border-b-2 border-l-2')} />
			<span className={cn(base, 'bottom-0 right-0 border-b-2 border-r-2')} />
		</span>
	);
}
