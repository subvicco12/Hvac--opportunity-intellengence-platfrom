import { CheckCircle2 } from 'lucide-react';
import type { UploadSession } from '@/lib/upload-types';
import { formatFileSize } from '@/lib/file-parser';
import { CornerBrackets } from '@/components/upload/corner-brackets';

export function FileSummary({ session }: { session: UploadSession }) {
	const stats: { label: string; value: string }[] = [
		{ label: 'File name', value: session.fileName },
		{ label: 'File type', value: session.fileType.toUpperCase() },
		{ label: 'File size', value: formatFileSize(session.fileSize) },
		{ label: 'Rows', value: session.sheet.rowCount.toLocaleString() },
		{ label: 'Columns', value: session.sheet.columnCount.toLocaleString() },
		...(session.fileType === 'xlsx'
			? [{ label: 'Worksheet', value: session.sheet.sheetName }]
			: []),
	];

	return (
		<section
			className="relative border-2 border-primary bg-card p-6 shadow-block sm:p-8"
			data-testid="file-summary"
			aria-label="File summary"
		>
			<CornerBrackets />
			<div className="flex items-center gap-3">
				<CheckCircle2 className="h-6 w-6 text-primary" strokeWidth={1.5} />
				<div>
					<p className="font-mono text-[11px] uppercase tracking-[0.25em] text-accent">
						Processing complete
					</p>
					<h2 className="font-display text-2xl font-semibold text-foreground">
						File summary
					</h2>
				</div>
			</div>

			<dl
				className="mt-6 grid grid-cols-2 gap-px border-2 border-border bg-border sm:grid-cols-3 lg:grid-cols-6"
				data-testid="file-summary-stats"
			>
				{stats.map((stat) => (
					<div
						key={stat.label}
						className="bg-background p-4"
						data-testid={`file-summary-stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
					>
						<dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
							{stat.label}
						</dt>
						<dd
							className="mt-1 truncate font-mono text-sm font-semibold text-foreground"
							title={stat.value}
						>
							{stat.value}
						</dd>
					</div>
				))}
			</dl>

			<div className="mt-6">
				<p className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
					Column headers
				</p>
				<ul
					className="mt-2 flex flex-wrap gap-2"
					data-testid="file-summary-headers"
			>
					{session.sheet.headers.map((header, i) => (
						<li
							key={`${header}-${i}`}
							className="border border-border bg-secondary px-2.5 py-1 font-mono text-xs text-foreground"
						>
							{header}
						</li>
					))}
				</ul>
			</div>
		</section>
	);
}
