import type { UploadSession } from '@/lib/upload-types';
import { UPLOAD_CONFIG } from '@/lib/upload-config';

export function PreviewTable({ session }: { session: UploadSession }) {
	const { headers, rowCount } = session.sheet;
	const rows = session.previewRows;

	return (
		<section
			className="border-2 border-primary bg-card shadow-block"
			data-testid="preview-table"
			aria-label="Data preview"
		>
			<div className="flex flex-wrap items-baseline justify-between gap-2 border-b-2 border-primary px-6 py-4">
				<h2 className="font-display text-2xl font-semibold text-foreground">
					Data preview
				</h2>
				<p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
					Showing first {rows.length} of {rowCount.toLocaleString()} rows
				</p>
			</div>
			<div className="overflow-x-auto">
			<table
				className="min-w-max w-full border-collapse text-left"
				data-testid="preview-table-grid"
			>
					<thead>
						<tr className="bg-primary">
							<th className="border-r border-primary-foreground/20 px-4 py-2.5 font-mono text-[11px] font-medium uppercase tracking-wider text-primary-foreground">
								#
							</th>
							{headers.map((header, i) => (
								<th
									key={`${header}-${i}`}
									className="whitespace-nowrap border-r border-primary-foreground/20 px-4 py-2.5 font-mono text-[11px] font-medium uppercase tracking-wider text-primary-foreground last:border-r-0"
								>
									{header}
								</th>
							))}
						</tr>
					</thead>
					<tbody>
						{rows.map((row, rowIndex) => (
							<tr
								key={rowIndex}
								className={
									rowIndex % 2 === 0 ? 'bg-background' : 'bg-secondary'
								}
							>
								<td className="border-r border-t border-border px-4 py-2 font-mono text-xs text-muted-foreground">
									{rowIndex + 1}
								</td>
								{headers.map((_, colIndex) => (
									<td
										key={colIndex}
										className="max-w-64 truncate whitespace-nowrap border-r border-t border-border px-4 py-2 text-sm text-foreground last:border-r-0"
										title={row[colIndex] ?? ''}
									>
										{row[colIndex] ?? ''}
									</td>
								))}
							</tr>
						))}
					</tbody>
				</table>
			</div>
			<p className="border-t-2 border-primary px-6 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
				Preview limited to {UPLOAD_CONFIG.previewRowLimit} rows · Full dataset
				staged in memory
			</p>
		</section>
	);
}
