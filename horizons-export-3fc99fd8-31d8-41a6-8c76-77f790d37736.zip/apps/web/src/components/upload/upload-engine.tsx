import { useState } from 'react';
import { AlertTriangle, ArrowRight, RotateCcw } from 'lucide-react';
import {
	UPLOAD_CONFIG,
	UPLOAD_ERROR_MESSAGES,
} from '@/lib/upload-config';
import type { UploadSession, WorkbookData } from '@/lib/upload-types';
import {
	UploadError,
	buildSheet,
	hasUsableData,
	parseCsvFile,
	parseXlsxFile,
	validateFile,
} from '@/lib/file-parser';
import { uploadStore } from '@/lib/upload-store';
import { UploadZone } from '@/components/upload/upload-zone';
import { WorksheetSelector } from '@/components/upload/worksheet-selector';
import { FileSummary } from '@/components/upload/file-summary';
import { PreviewTable } from '@/components/upload/preview-table';

type Status = 'idle' | 'processing' | 'awaiting-sheet' | 'success' | 'error';

export function UploadEngine() {
	const [status, setStatus] = useState<Status>('idle');
	const [error, setError] = useState<string | null>(null);
	const [workbook, setWorkbook] = useState<WorkbookData | null>(null);
	const [session, setSession] = useState<UploadSession | null>(null);
	const [continued, setContinued] = useState(false);

	const fail = (e: unknown) => {
		uploadStore.clear();
		setSession(null);
		setWorkbook(null);
		if (e instanceof UploadError) {
			setError(e.message);
		} else {
			setError(UPLOAD_ERROR_MESSAGES.failure);
		}
		setStatus('error');
	};

	const stageSheet = (wb: WorkbookData, sheetName: string) => {
		const source = wb.sheets.find((s) => s.name === sheetName);
		if (!source) throw new UploadError('failure');
		const sheet = buildSheet(sheetName, source.rows);
		const staged: UploadSession = {
			fileName: wb.fileName,
			fileType: wb.fileType,
			fileSize: wb.fileSize,
			sheet,
			previewRows: sheet.rows.slice(0, UPLOAD_CONFIG.previewRowLimit),
			uploadedAt: new Date().toISOString(),
		};
		uploadStore.set(staged);
		setSession(staged);
		setWorkbook(null);
		setStatus('success');
	};

	const handleFile = async (file: File) => {
		setStatus('processing');
		setError(null);
		setSession(null);
		setWorkbook(null);
		setContinued(false);
		uploadStore.clear();

		try {
			const type = validateFile(file);
			const wb =
				type === 'csv' ? await parseCsvFile(file) : await parseXlsxFile(file);

			const usableSheets = wb.sheets.filter((s) => hasUsableData(s.rows));
			if (usableSheets.length === 0) throw new UploadError('empty');

			if (wb.sheets.length === 1 || !UPLOAD_CONFIG.multiSheetEnabled) {
				stageSheet(wb, usableSheets[0].name);
			} else {
				setWorkbook(wb);
				setStatus('awaiting-sheet');
			}
		} catch (e) {
			fail(e);
		}
	};

	const reset = () => {
		uploadStore.clear();
		setStatus('idle');
		setError(null);
		setWorkbook(null);
		setSession(null);
		setContinued(false);
	};

	return (
		<div className="space-y-8" data-testid="upload-engine">
			{status !== 'success' && status !== 'awaiting-sheet' && (
				<UploadZone processing={status === 'processing'} onFile={handleFile} />
			)}

			{status === 'error' && error && (
				<div
					role="alert"
					aria-live="assertive"
					data-testid="error-message"
					className="flex items-start gap-3 border-2 border-accent bg-card p-4 shadow-block-ox"
				>
					<AlertTriangle
						className="mt-0.5 h-5 w-5 shrink-0 text-accent"
						strokeWidth={1.5}
					/>
					<div>
						<p className="font-mono text-[11px] uppercase tracking-[0.25em] text-accent">
							Upload rejected
						</p>
						<p className="mt-1 text-sm font-medium text-foreground">{error}</p>
					</div>
				</div>
			)}

			{status === 'awaiting-sheet' && workbook && (
				<WorksheetSelector
					workbook={workbook}
					onSelect={(name) => {
						try {
							stageSheet(workbook, name);
						} catch (e) {
							fail(e);
						}
					}}
					onCancel={reset}
				/>
			)}

			{status === 'success' && session && (
				<>
					<FileSummary session={session} />
					<PreviewTable session={session} />
					<div className="flex flex-wrap items-center gap-4 border-t-2 border-border pt-6">
						<button
							type="button"
							onClick={() => setContinued(true)}
							data-testid="continue-button"
							className="inline-flex items-center gap-2 border-2 border-primary bg-primary px-8 py-3 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground shadow-block-sm transition-transform duration-100 hover:-translate-y-px active:scale-[0.98]"
						>
							Continue
							<ArrowRight className="h-4 w-4" strokeWidth={2} />
						</button>
						<button
							type="button"
							onClick={reset}
							data-testid="reset-button"
							className="inline-flex items-center gap-2 border-2 border-border bg-background px-6 py-3 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-foreground transition-colors hover:border-primary"
						>
							<RotateCcw className="h-4 w-4" strokeWidth={2} />
							Upload a different file
						</button>
						{continued && (
							<p
								className="font-mono text-[11px] uppercase tracking-[0.2em] text-accent"
								data-testid="continue-confirmation"
							>
								Data staged — ready for the next build unit.
							</p>
						)}
					</div>
				</>
			)}

			{status !== 'success' && (
				<button
					type="button"
					disabled
					aria-disabled="true"
					data-testid="continue-button-disabled"
					className="inline-flex cursor-not-allowed items-center gap-2 border-2 border-border bg-muted px-8 py-3 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground opacity-60"
				>
					Continue
					<ArrowRight className="h-4 w-4" strokeWidth={2} />
				</button>
			)}
		</div>
	);
}
