import { useRef, useState } from 'react';
import { FileUp, Loader2 } from 'lucide-react';
import { UPLOAD_CONFIG } from '@/lib/upload-config';
import { CornerBrackets } from '@/components/upload/corner-brackets';
import { cn } from '@/lib/utils';

interface UploadZoneProps {
	processing: boolean;
	onFile: (file: File) => void;
}

export function UploadZone({ processing, onFile }: UploadZoneProps) {
	const inputRef = useRef<HTMLInputElement>(null);
	const [dragging, setDragging] = useState(false);

	const handleDrop = (e: React.DragEvent) => {
		e.preventDefault();
		setDragging(false);
		if (processing) return;
		const file = e.dataTransfer.files?.[0];
		if (file) onFile(file);
	};

	return (
		<div
			role="button"
			tabIndex={0}
			aria-label="Upload a CSV or XLSX file"
			data-testid="upload-zone"
			onClick={() => !processing && inputRef.current?.click()}
			onKeyDown={(e) => {
				if (!processing && (e.key === 'Enter' || e.key === ' ')) {
					e.preventDefault();
					inputRef.current?.click();
				}
			}}
			onDragOver={(e) => {
				e.preventDefault();
				if (!processing) setDragging(true);
			}}
			onDragLeave={() => setDragging(false)}
			onDrop={handleDrop}
			className={cn(
				'relative flex min-h-64 cursor-pointer flex-col items-center justify-center gap-4 border-2 border-dashed border-primary bg-card px-6 py-12 text-center transition-colors duration-200',
				dragging && 'border-solid border-accent bg-secondary',
				processing && 'cursor-wait',
			)}
		>
			<CornerBrackets />
			<input
				ref={inputRef}
				type="file"
				accept={UPLOAD_CONFIG.acceptAttribute}
				aria-label="Choose a CSV or XLSX file from your device"
				data-testid="file-input"
				className="hidden"
				onChange={(e) => {
					const file = e.target.files?.[0];
					if (file) onFile(file);
					e.target.value = '';
				}}
			/>
			{processing ? (
				<div data-testid="processing-indicator" role="status" aria-live="polite">
					<Loader2
						className="h-10 w-10 animate-spin text-primary"
						strokeWidth={1.5}
					/>
					<p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">
						Processing file…
					</p>
					<p className="text-sm text-muted-foreground">
						Validating, parsing, and staging your data locally.
					</p>
				</div>
			) : (
				<>
					<span className="flex h-16 w-16 items-center justify-center border-2 border-primary bg-background shadow-block-sm">
						<FileUp className="h-7 w-7 text-primary" strokeWidth={1.5} />
					</span>
					<div>
						<p className="font-display text-2xl font-semibold text-foreground">
							Drag &amp; drop your file here
						</p>
						<p className="mt-1 text-sm text-muted-foreground">
							or{' '}
							<span
								className="font-semibold text-accent underline underline-offset-4"
								data-testid="choose-file-link"
							>
								choose a file
							</span>{' '}
							from your device
						</p>
					</div>
					<p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
						CSV or XLSX · Max {UPLOAD_CONFIG.maxFileSizeMb} MB · Processed
						locally, never stored
					</p>
				</>
			)}
		</div>
	);
}
