import { useState } from 'react';
import { Table2 } from 'lucide-react';
import type { WorkbookData } from '@/lib/upload-types';
import { hasUsableData } from '@/lib/file-parser';
import { CornerBrackets } from '@/components/upload/corner-brackets';
import { cn } from '@/lib/utils';

interface WorksheetSelectorProps {
	workbook: WorkbookData;
	onSelect: (sheetName: string) => void;
	onCancel: () => void;
}

export function WorksheetSelector({
	workbook,
	onSelect,
	onCancel,
}: WorksheetSelectorProps) {
	const [selected, setSelected] = useState<string>(
		workbook.sheets.find((s) => hasUsableData(s.rows))?.name ??
			workbook.sheets[0]?.name ??
			'',
	);

	return (
		<section
			className="relative border-2 border-primary bg-card p-6 shadow-block sm:p-8"
			data-testid="worksheet-selector"
			aria-label="Worksheet selector"
		>
			<CornerBrackets />
			<p className="font-mono text-[11px] uppercase tracking-[0.25em] text-accent">
				Multiple worksheets detected
			</p>
			<h2 className="mt-2 font-display text-2xl font-semibold text-foreground">
				Select a worksheet
			</h2>
			<p className="mt-1 text-sm text-muted-foreground">
				<span className="font-medium text-foreground">{workbook.fileName}</span>{' '}
				contains {workbook.sheets.length} worksheets. Choose which one to
				analyze.
			</p>

			<div className="mt-6 grid gap-3 sm:grid-cols-2" data-testid="worksheet-options">
				{workbook.sheets.map((sheet) => {
					const usable = hasUsableData(sheet.rows);
					return (
						<button
							key={sheet.name}
							type="button"
							onClick={() => setSelected(sheet.name)}
							aria-pressed={selected === sheet.name}
							aria-label={`Select worksheet ${sheet.name}`}
							data-testid={`worksheet-option-${sheet.name}`}
							className={cn(
								'flex items-center gap-3 border-2 px-4 py-3 text-left transition-colors duration-150',
								selected === sheet.name
									? 'border-accent bg-secondary shadow-block-sm'
									: 'border-border bg-background hover:border-primary',
							)}
						>
							<Table2
								className={cn(
									'h-5 w-5 shrink-0',
									selected === sheet.name
										? 'text-accent'
										: 'text-muted-foreground',
								)}
								strokeWidth={1.5}
							/>
							<span className="min-w-0">
								<span className="block truncate font-mono text-sm font-medium text-foreground">
									{sheet.name}
								</span>
								<span className="block font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
									{usable ? 'Contains data' : 'Empty worksheet'}
								</span>
							</span>
						</button>
					);
				})}
			</div>

			<div className="mt-6 flex flex-wrap items-center gap-3">
				<button
					type="button"
					onClick={() => selected && onSelect(selected)}
					disabled={!selected}
					data-testid="process-worksheet-button"
					className="border-2 border-primary bg-primary px-6 py-2.5 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-transform duration-100 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
				>
					Process worksheet
				</button>
				<button
					type="button"
					onClick={onCancel}
					data-testid="worksheet-cancel-button"
					className="border-2 border-border bg-background px-6 py-2.5 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-foreground transition-colors hover:border-primary"
				>
					Cancel
				</button>
			</div>
		</section>
	);
}
