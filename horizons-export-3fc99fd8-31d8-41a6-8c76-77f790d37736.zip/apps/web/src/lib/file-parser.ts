import * as XLSX from 'xlsx';
import {
	UPLOAD_CONFIG,
	UPLOAD_ERROR_MESSAGES,
	type UploadErrorCode,
} from '@/lib/upload-config';
import type {
	FileType,
	ParsedSheet,
	SheetSource,
	WorkbookData,
} from '@/lib/upload-types';

export class UploadError extends Error {
	readonly code: UploadErrorCode;

	constructor(code: UploadErrorCode) {
		super(UPLOAD_ERROR_MESSAGES[code]);
		this.name = 'UploadError';
		this.code = code;
	}
}

export function detectFileType(fileName: string): FileType | null {
	const ext = fileName.split('.').pop()?.toLowerCase();
	if (ext === 'csv' || ext === 'xlsx') return ext;
	return null;
}

/** Validate type and size before any parsing happens. */
export function validateFile(file: File): FileType {
	const type = detectFileType(file.name);
	if (!type) throw new UploadError('unsupported');
	if (file.size > UPLOAD_CONFIG.maxFileSizeBytes)
		throw new UploadError('oversized');
	if (file.size === 0) throw new UploadError('empty');
	return type;
}

/** RFC-4180-aware CSV parser: quoted fields, escaped quotes, CRLF, BOM. */
export function parseCsvText(text: string): string[][] {
	const src = text.replace(/^﻿/, ''); // strip BOM
	const rows: string[][] = [];
	let field = '';
	let row: string[] = [];
	let inQuotes = false;

	for (let i = 0; i < src.length; i++) {
		const ch = src[i];
		if (inQuotes) {
			if (ch === '"') {
				if (src[i + 1] === '"') {
					field += '"';
					i++;
				} else {
					inQuotes = false;
				}
			} else {
				field += ch;
			}
		} else if (ch === '"') {
			inQuotes = true;
		} else if (ch === ',') {
			row.push(field);
			field = '';
		} else if (ch === '\n' || ch === '\r') {
			if (ch === '\r' && src[i + 1] === '\n') i++;
			row.push(field);
			field = '';
			rows.push(row);
			row = [];
		} else {
			field += ch;
		}
	}
	if (field.length > 0 || row.length > 0) {
		row.push(field);
		rows.push(row);
	}
	return rows;
}

function isRowEmpty(row: string[]): boolean {
	return row.every((cell) => cell.trim() === '');
}

/** Drop empty edges, rectangularize, and report whether anything usable remains. */
export function normalizeRows(raw: string[][]): string[][] {
	const rows = raw.filter((r) => Array.isArray(r));
	while (rows.length > 0 && isRowEmpty(rows[0])) rows.shift();
	while (rows.length > 0 && isRowEmpty(rows[rows.length - 1])) rows.pop();
	const width = rows.reduce((max, r) => Math.max(max, r.length), 0);
	return rows.map((r) => {
		const padded = r.slice(0, width);
		while (padded.length < width) padded.push('');
		return padded;
	});
}

export function hasUsableData(raw: string[][]): boolean {
	return normalizeRows(raw).length > 0;
}

/** Build the processed sheet (headers + data rows) from a raw worksheet. */
export function buildSheet(sheetName: string, raw: string[][]): ParsedSheet {
	const rows = normalizeRows(raw);
	if (rows.length === 0) throw new UploadError('empty');

	const columnCount = rows[0].length;
	const headers = rows[0].map(
		(h, i) => h.trim() || `Column ${i + 1}`,
	);
	const dataRows = rows.slice(1);

	return {
		sheetName,
		headers,
		rows: dataRows,
		rowCount: dataRows.length,
		columnCount,
	};
}

/** Parse a CSV file into a single-sheet workbook. */
export async function parseCsvFile(file: File): Promise<WorkbookData> {
	let text: string;
	try {
		text = await file.text();
	} catch {
		throw new UploadError('unreadable');
	}
	return {
		fileName: file.name,
		fileType: 'csv',
		fileSize: file.size,
		sheets: [{ name: 'Sheet 1', rows: parseCsvText(text) }],
	};
}

/** Parse an XLSX file into a multi-sheet workbook (all worksheets detected). */
export async function parseXlsxFile(file: File): Promise<WorkbookData> {
	let buffer: ArrayBuffer;
	try {
		buffer = await file.arrayBuffer();
	} catch {
		throw new UploadError('unreadable');
	}

	let workbook: XLSX.WorkBook;
	try {
		workbook = XLSX.read(buffer, { type: 'array' });
	} catch {
		throw new UploadError('unreadable');
	}

	const sheets: SheetSource[] = workbook.SheetNames.map((name) => {
		const ws = workbook.Sheets[name];
		const raw = XLSX.utils.sheet_to_json<unknown[]>(ws, {
			header: 1,
			defval: '',
			blankrows: false,
			raw: false,
		});
		return {
			name,
			rows: raw.map((r) => (Array.isArray(r) ? r.map((c) => String(c ?? '')) : [])),
		};
	});

	if (sheets.length === 0) throw new UploadError('unreadable');

	return {
		fileName: file.name,
		fileType: 'xlsx',
		fileSize: file.size,
		sheets,
	};
}

export function formatFileSize(bytes: number): string {
	if (bytes < 1024) return `${bytes} B`;
	if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
	return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
