/**
 * The public origin of this site, e.g. `https://example.com`. Use it for
 * absolute URLs that leave the app — sitemap `<loc>`, canonical links, `og:url`.
 *
 * TLS terminates at the proxy in front of this server, which forwards plain
 * HTTP, so the request protocol is always `http`. `X-Forwarded-Proto` carries
 * the scheme the visitor actually used, and `Host` carries the public domain.
 * Only the origin is read here, so the `.data` suffix React Router adds to
 * `request.url` on client navigations does not matter.
 */
export const siteOrigin = (request: Request): string => {
	const { host, protocol } = new URL(request.url);
	const [forwardedProtocol] = request.headers.get('x-forwarded-proto')?.split(',') ?? [];

	return `${forwardedProtocol?.trim() || protocol.replace(':', '')}://${host}`;
};
