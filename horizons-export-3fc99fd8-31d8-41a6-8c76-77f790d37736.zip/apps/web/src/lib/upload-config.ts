/**
 * CENTRAL UPLOAD CONFIGURATION — single source of truth for BU-001.
 * Future build units must import from here, never re-declare these values.
 */
export const UPLOAD_CONFIG = {
	allowedFileTypes: ['csv', 'xlsx'] as const,
	acceptAttribute: '.csv,.xlsx',
	maxFileSizeMb: 10,
	maxFileSizeBytes: 10 * 1024 * 1024,
	previewRowLimit: 20,
	multiSheetEnabled: true,
	retainOriginalFile: false,
} as const;

export type UploadErrorCode =
	| 'unsupported'
	| 'oversized'
	| 'unreadable'
	| 'empty'
	| 'failure';

export const UPLOAD_ERROR_MESSAGES: Record<UploadErrorCode, string> = {
	unsupported: 'Unsupported file type. Please upload a CSV or XLSX file.',
	oversized: 'This file exceeds the maximum allowed size.',
	unreadable:
		"We couldn't read this file. It may be corrupted or improperly formatted.",
	empty: 'No usable data was found in this file.',
	failure: 'Something went wrong while processing your file. Please try again.',
};
