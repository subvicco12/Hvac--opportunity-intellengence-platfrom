import type { UploadSession } from '@/lib/upload-types';

/**
 * In-memory upload store — the modular hand-off point for future build units.
 * The original file is never retained (retain_original_file: false); only the
 * parsed, normalized session data is staged here for the next pipeline step.
 */
let currentSession: UploadSession | null = null;

export const uploadStore = {
	set(session: UploadSession): void {
		currentSession = session;
	},
	get(): UploadSession | null {
		return currentSession;
	},
	clear(): void {
		currentSession = null;
	},
};
