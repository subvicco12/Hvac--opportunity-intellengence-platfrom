import type { UPLOAD_CONFIG } from '@/lib/upload-config';

export type FileType = (typeof UPLOAD_CONFIG.allowedFileTypes)[number];

/** Raw worksheet as parsed from the file, before header/shape normalization. */
export interface SheetSource {
	name: string;
	rows: string[][];
}

/** In-memory representation of an uploaded workbook (original file is NOT retained). */
export interface WorkbookData {
	fileName: string;
	fileType: FileType;
	fileSize: number;
	sheets: SheetSource[];
}

/** A fully processed worksheet: headers + normalized data rows. */
export interface ParsedSheet {
	sheetName: string;
	headers: string[];
	rows: string[][];
	rowCount: number;
	columnCount: number;
}

/** The staged result kept available for future build units via the upload store. */
export interface UploadSession {
	fileName: string;
	fileType: FileType;
	fileSize: number;
	sheet: ParsedSheet;
	previewRows: string[][];
	uploadedAt: string;
}
