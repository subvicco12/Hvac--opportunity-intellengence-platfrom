import type { Route } from './+types/home';
import { UploadEngine } from '@/components/upload/upload-engine';
import { UPLOAD_CONFIG } from '@/lib/upload-config';

export function meta(_args: Route.MetaArgs) {
	return [
		{ title: 'Upload Your HVAC Data — HVAC Opportunity Intelligence' },
		{
			name: 'description',
			content:
				'Upload your CSV or Excel file to begin analyzing your HVAC quotes and opportunities. Files are validated and parsed locally in your browser.',
		},
	];
}

export default function Home() {
	return (
		<div className="min-h-[100dvh] bg-background grid-lines">
			<div className="mx-auto min-h-[100dvh] max-w-5xl border-x-2 border-border bg-background">
				<header className="flex items-center justify-between gap-4 border-b-2 border-border px-6 py-4 sm:px-10">
					<p className="font-mono text-[11px] font-semibold uppercase tracking-[0.25em] text-foreground">
						HVAC Opportunity Intelligence
					</p>
					<p className="font-mono text-[11px] uppercase tracking-[0.25em] text-accent">
						BU-001 / Upload Engine
					</p>
				</header>

				<main className="px-6 py-12 sm:px-10 sm:py-16">
					<div className="max-w-2xl">
						<p className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
							<span className="inline-block h-2.5 w-2.5 bg-accent" />
							Step 01 — Data intake
						</p>
						<h1 className="mt-4 font-display text-4xl font-bold leading-[1.05] tracking-tight text-foreground sm:text-6xl">
							Upload Your HVAC Data
						</h1>
						<p className="mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg">
							Upload your CSV or Excel file to begin analyzing your quotes and
							opportunities.
						</p>
					</div>

					<div className="mt-10">
						<UploadEngine />
					</div>

					<div className="mt-10 grid gap-px border-2 border-border bg-border sm:grid-cols-3">
						{[
							{
								label: 'Accepted formats',
								value: UPLOAD_CONFIG.allowedFileTypes
									.join(' / ')
									.toUpperCase(),
							},
							{
								label: 'Maximum file size',
								value: `${UPLOAD_CONFIG.maxFileSizeMb} MB`,
							},
							{
								label: 'Data handling',
								value: 'Local only — never stored',
							},
						].map((item) => (
							<div key={item.label} className="bg-card p-4" data-testid={`spec-${item.label.toLowerCase().replace(/\s+/g, '-')}`}>
								<p className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
									{item.label}
								</p>
								<p className="mt-1 font-mono text-sm font-semibold text-foreground">
									{item.value}
								</p>
							</div>
						))}
					</div>
				</main>

				<footer className="border-t-2 border-border px-6 py-4 sm:px-10">
					<p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
						Files are processed in your browser and discarded after parsing · ©
						2026 HVAC Opportunity Intelligence
					</p>
				</footer>
			</div>
		</div>
	);
}
