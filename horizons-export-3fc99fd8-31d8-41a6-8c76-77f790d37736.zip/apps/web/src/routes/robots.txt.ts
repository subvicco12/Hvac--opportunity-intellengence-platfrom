import type { Route } from './+types/robots.txt';
import { siteOrigin } from '@/lib/site-origin.server';

/**
 * Hostinger-provided hosts: the editor sandbox preview, and the domain a site is
 * published on before its owner connects one of their own. Neither should reach a
 * search index — the site is not on its final URL yet.
 */
const UNPUBLISHED_HOST_SUFFIXES = [
	'.app-preview.com',
	'.app-preview.io',
	'.hostingersite.com',
	'.hostingersite.dev',
];

export function loader({ request }: Route.LoaderArgs) {
	const origin = siteOrigin(request);
	const { hostname } = new URL(origin);
	const isUnpublished = UNPUBLISHED_HOST_SUFFIXES.some(suffix => hostname.endsWith(suffix));
	const lines = isUnpublished
		? ['User-agent: *', 'Disallow: /']
		: ['User-agent: *', 'Allow: /', `Sitemap: ${origin}/sitemap.xml`];

	return new Response(`${lines.join('\n')}\n`, {
		headers: {
			'Content-Type': 'text/plain; charset=utf-8',
			'Cache-Control': 'public, max-age=3600',
		},
	});
}
